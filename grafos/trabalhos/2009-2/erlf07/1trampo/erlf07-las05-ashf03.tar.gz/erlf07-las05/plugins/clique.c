#include "clique.h"

Pgin*
pgin_info(void) {
    Pgin *pgin;
    pgin = (Pgin *) malloc(2 * sizeof(Pgin));

    /* Inclui clique como primeiro algoritmo do plugin */
    pgin[0].type = PGIN_TEST_ALG;
    pgin[0].label = "Clique";
    pgin[0].name = "clique";
    pgin[0].flags = 0;

    /* Indica o final da lista de algoritmos */
    pgin[1].type = PGIN_LIST_END;
    pgin[1].label = 0;
    pgin[1].name = 0;
    pgin[1].flags = 0;

    return pgin;
}


int 
getParameters(Graph *G, char *mess){
    int i;
    double d;
    char *s;

    i = pgin_read_int("Get some parameters", 
                      "Give me an int", 10, 1, 2000000, 1);
    d = pgin_read_double("Get some parameters", 
                         "Give me a double", 0.0, -10.0, 10.0, 0.1, 1);
    s = pgin_read_string("Get some parameters", 
                         "Give me a string", "I'm a string", 40);

    sprintf(mess, "I got: %d, %f and '%s'. Thanks!", i, d, s);
    free(s);

    return i;
}

/** Colore todos os vertices com a cor 'color'*/
int 
paintAllPoints(Graph *G, int color) {
    int i;
    for (i=0; i<G->size; i++)
        G->vertex[i].color = color;
    return 1;
}

/** Colore o vertice da posicao 'pos' com a cor 'color'*/
int 
paintPoint(Graph *G, int pos, int color) {
    G->vertex[pos].color = color;
    return 1;
}

/** Colore todas as arestas com a cor 'color'*/
int 
paintAllEdges(Graph *G, int color) {
    int i,j;
    for (i=0; i<G->nedges; i++)
        for (j=0; j<G->nedges; j++)
            G->prop[i][j].color = color;
    return 1;
}

/** Colore a aresta da posicao 'x,y' com a cor 'color'*/
void
paintEdge(Graph *G, int x, int y, int color) {
    G->prop[x][y].color = color;
}

void
paintMaior(Graph *G, Mclique maior, int color) {
    int k,l;
    for (k=maior.lin; k<maior.tam; k++)
        for (l=maior.col_inicio; l<maior.col_fim; l++) 
            G->prop[k][l].color = color;
};

void
printMatrizAdj(Graph *G) {
    int k,l;
    for (k=0; k<G->size; k++) {
        for (l=0; l<G->size; l++) 
            printf("%d",G->edge[k][l]);
        printf("\n");
    }
}

int
kClique(int *lista, Graph *G, int grau) {
   int i,j;
   j=0;

   for(i=0; i<G->size; i++) {
       if (G->vertex[i].degree >= grau) {
            lista[j++] = i;
        printf ("Dentro de kClique: grau (%d) elemento(%d)\n",grau,lista[j-1]);
       }
    }
     printf ("kClique retornando j=%d\n",j);

    /* uma K-clique tem K+1 vertices */
    return (j==grau) ? 1 : 0;
}

int
conexos(int *l, int tam, Graph *G) {
   int i,j;
   if (tam <= 1)
      return 0; 

   for(i=0; i<tam; i++)
      for( j=0; j<tam; j++) {
         if (i!=j) {
             printf("tam(%d) i(%d) j(%d) l[%d][%d]: %d\n",
                    tam, i,j,l[i],l[j],G->edge[l[i]][l[j]]);
             if (!G->edge[l[i]][l[j]])
                return 0;
         }
      }
   return 1;
}


void
pinta (int *lista, int tam, Graph *G, int color) {
   int i,j;
   /* pintando vertices */
   for(i=0; i<tam; i++) {
       printf("pintando o vertice: %d\n", lista[i]);
       paintPoint(G,lista[i],color);
    }
   /* pintando arestas */
   for(i=0; i<tam; i++)
      for(j=i+1; j<tam; j++) {
           if (G->edge[lista[i]][lista[j]])
            printf("pintando a aresta: %d,%d\n", lista[i],lista[j]);
            G->prop[lista[i]][lista[j]].color = color;
      }
}

/** */
void 
Edges(Graph *G, int color) {
    int grau;
    int *lista1;

    lista1 = (int*)malloc(G->size * sizeof(int)); 

    printMatrizAdj(G);
    
    for (grau=G->size-1; grau>=1; grau--) {
        if (kClique(lista1,G,grau) && conexos(lista1,grau+1,G)) {
            printf (" grau %d entrando em conexos\n",grau);
            pinta(lista1,grau+1,G,color);
        }
    }

}


/** Esta funcao e' a funcao principal do plugin */
int 
clique(Graph *G, char *mess) {
    sprintf(mess, "Clique");
    Edges(G,BLUE);
    return 1;
}


#include "helloworld.h"

Pgin*
pgin_info(void) {
    Pgin *pgin;
    pgin = (Pgin *) malloc(2 * sizeof(Pgin));

    /* Inclui HelloWorld como primeiro algoritmo do plugin */
    pgin[0].type = PGIN_TEST_ALG;
    pgin[0].label = "Hello World!";
    pgin[0].name = "HelloWorld";
    pgin[0].flags = 0;

    /* Indica o final da lista de algoritmos */
    pgin[1].type = PGIN_LIST_END;
    pgin[1].label = 0;
    pgin[1].name = 0;
    pgin[1].flags = 0;

    return pgin;
}

int 
HelloWorld(Graph *G, char *mess) {
    sprintf(mess, "Hello World!");
    return 1;
}

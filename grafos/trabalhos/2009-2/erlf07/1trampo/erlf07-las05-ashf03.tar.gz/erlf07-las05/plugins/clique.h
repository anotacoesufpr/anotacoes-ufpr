#include <stdio.h>
#include <stdlib.h>
#include "../pgin.h"
#include "../graph.h"

#define GREEN 1
#define BLUE 2 
#define YELLOW 3 
#define CYAN 4 

typedef struct {
    int lin;
    int col_inicio;
    int col_fim;
    int tam;
} Mclique;
Pgin *pgin_info(void);

int clique(Graph *G, char *mess);
int getParameters(Graph *G, char *mess);


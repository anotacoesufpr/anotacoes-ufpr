#include <stdio.h>
#include <stdlib.h>
#include "../pgin.h"
#include "../graph.h"


Pgin *pgin_info(void);

int HelloWorld(Graph *G, char *mess);


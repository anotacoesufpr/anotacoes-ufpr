#include <algorithm>
#include <iostream>
#include <cstdio>
#include <string.h>
using namespace std;

typedef struct edges {
    int x,y;
} Edges;


void print_graph (int **G, int lin, int col) {
    int i=0, j=0;
    cout << "line: " << lin << endl; 
    cout << "column: "  << col << endl;
    for(i=0; i<lin; i++) {
        for(j=0; j<col; j++)
            cout << G[i][j];
        cout << endl;
    }
    cout << endl;
}

int** read_graph(char *fname, int **G, int *lin, int *col) {
    FILE * f;
    int newline=0, column=0, column_size=0;
    int vertex=0; 
    char c;


    f = fopen(fname, "r");
    while (fscanf(f, "%c", &c) != EOF) {
        switch (c) {
            case '\n': 
                newline++; 
                column = 0;
            break;
            default:
                column++; 
                if (column >= column_size)
                    column_size = column;
            break;
        }
    }
    fclose(f);

    *lin = newline;
    *col = column_size;

    int i=0,j=0;
    G = (int**)malloc(sizeof(int)*(*lin));
    for (i=0; i<(*lin); i++)
        G[i] = (int*)malloc(sizeof(int)*(*col));

    for(i=0; i<(*lin); i++)
        for(j=0; j<(*col); j++)
            G[i][j] = 0;

    i=0; j=0;
    f = fopen(fname, "r");
    while (fscanf(f, "%c", &c) != EOF) {
        switch (c) {
            case '\n':  
                j=0; i++;
            break;
            case ' ':   
                j++;
            break;
            case 'c':  
                G[i][j] = 1;
                j++;
            break;
            default: 
                return NULL;
        }
    }
    fclose(f);


    
    f = fopen(fname, "r");
    while (fscanf(f, "%c", &c) != EOF)
        switch (c) {
            case 'c': 
                vertex++;
            break;
        }
    fclose(f);


    int **H;
    H = (int**)malloc(sizeof(int)*vertex);
    i=0,j=0;
    for (i=0; i<vertex; i++)
        H[i] = (int*)malloc(sizeof(int)*vertex);

    for(i=0; i<vertex; i++)
        for(j=0; j<vertex; j++)
            H[i][j] = 0;

    int ne=0;
    for(i=0; i<(*lin); i++) 
        for(j=0; j<(*col); j++) 
            if (G[i][j] == 1) 
                ne++;

    int k=0;
    Edges *v_edges = (Edges*)malloc(sizeof(Edges)*ne);
    for(i=0; i<(*lin); i++) {
        for(j=0; j<(*col); j++) {
            if (G[i][j] == 1) {
                v_edges[k].x = i;
                v_edges[k++].y = j;
            }
        }
    }

//    for(i=0; i<ne; i++)
//        cout << v_edges[i].x << v_edges[i].y << endl;

    for(i=0; i<vertex; i++)
        for(j=0; j<vertex; j++)
            if (((v_edges[i].x)+1) == v_edges[j].x && v_edges[i].y == v_edges[j].y)
                H[i][j]=1;                

    for(i=0; i<vertex; i++)
        for(j=0; j<vertex; j++)
            if (v_edges[i].x == v_edges[j].x && ((v_edges[i].y) + 1) == v_edges[j].y)
                H[i][j]=1;                

    for(i=0; i<vertex; i++)
        for(j=0; j<vertex; j++)
            if (((v_edges[i].x)-1) == v_edges[j].x && v_edges[i].y == v_edges[j].y)
                H[i][j]=1;                

    for(i=0; i<vertex; i++)
        for(j=0; j<vertex; j++)
            if (v_edges[i].x == v_edges[j].x && ((v_edges[i].y)- 1) == v_edges[j].y)
                H[i][j]=1;                
    *lin = vertex; 
    *col = vertex;
    return H;
}

int main (int argc, char **argv) {
    int i,j, isomorph=0;
    int **G, lin, col;
    int **G1, lin1, col1;

    /* entrada invalida*/
    if (argc<3) 
        return 1;

    G = read_graph(argv[1], G, &lin, &col); 
    G1 = read_graph(argv[2], G1, &lin1, &col1); 

    /* caracter invalido na entrada */
    if (!G || !G1) return 1;

    // DEBUG: imprimir matriz de adjacencia 
    // print_graph(G, lin, col);
    // print_graph(G1, lin1, col1);

    /* nao sao isomorficos */
    if (lin != lin1) {
        cout << 0 << endl;
        return 0;
    }

    /* populando o vetor de permutacao */
    int v[lin];
    for (i=0; i<lin; i++)
        v[i] = i;

    /* verificando se os grafos sao isomorficos */
    do {
        isomorph=1;
        for (i=0; i<lin; i++) {
            for (j=0;j<lin;j++) {
                if (G[i][j] != G1[v[i]][v[j]]) {
                    isomorph = 0;
                    break; 
                }
            }
        }
        if (isomorph) {
            // DEBUG: imprimir a permutacao que faz os grafos serem isomorficos
            // for (i=0;i<N;i++)
            //     cout << v[i];
            // cout << endl;
            cout << "1" << endl;
            return 0;
        }
    } while (next_permutation(v,v+lin));

    cout << "0" << endl;
    return 1;
}
